﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace LoginTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string userid = "";
            string password = ""; 
            Console.Write("Username: ");
            userid = Console.ReadLine();
            Console.Write("Pass: ");
            password = Console.ReadLine();
            Console.WriteLine(userid + password);
            TestHash test = new TestHash();
            password = test.HashPass(password);
            Console.WriteLine(userid + password);
            Console.ReadKey();
            
        }
        
    }
}
